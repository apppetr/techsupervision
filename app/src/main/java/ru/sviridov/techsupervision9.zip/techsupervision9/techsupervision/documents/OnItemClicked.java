package ru.sviridov.techsupervision.documents;

import android.support.annotation.MenuRes;

public interface OnItemClicked {
   void onClicked(long var1, @MenuRes int var3);
}
