package ru.sviridov.techsupervision.utils.vectors;

import android.graphics.Canvas;

public interface ImagePatch {
   void draw(Painting var1, Canvas var2);
}
