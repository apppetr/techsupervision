package ru.sviridov.techsupervision.docx;

public interface ISaver {
   boolean save();
}
