package ru.sviridov.techsupervision.service;

public class Error {
   private int code;
   private String message;
}
