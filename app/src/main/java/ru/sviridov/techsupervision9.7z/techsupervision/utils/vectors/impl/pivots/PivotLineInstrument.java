package ru.sviridov.techsupervision.utils.vectors.impl.pivots;

import android.graphics.Canvas;
import android.graphics.PointF;
import android.view.MotionEvent;

import org.json.JSONException;

import java.util.ArrayList;
import ru.sviridov.techsupervision.utils.vectors.Painting;
import ru.sviridov.techsupervision.utils.vectors.impl.LineFImagePatch;

/* renamed from: ru.sviridov.techsupervision.utils.vectors.impl.pivots.PivotLineInstrument */
public class PivotLineInstrument extends PivotInstrument {
    LineFImagePatch draw = new LineFImagePatch(new PointF(), new PointF());

    /* renamed from: sp */
    PointF f90sp = new PointF();
    boolean start = true;

   public PivotLineInstrument() throws JSONException {
   }

   /* access modifiers changed from: protected */
    public void restrictPivots(int changedPivotIndex) {
    }

    public void handleEvent(Painting target, MotionEvent event) {
        boolean z = this.start;
        this.start = false;
        if (z || false) {
            this.pivots = new ArrayList();
            this.f90sp.set(event.getX(), event.getY());
            initializePivots(target);
            this.pressedPivotIndex = 1;
        }
        super.handleEvent(target, event);
    }

    /* access modifiers changed from: protected */
    public void initializePivots(Painting target) {
        this.pivots.add(new PointF(this.f90sp.x, this.f90sp.y));
        this.pivots.add(new PointF(this.f90sp.x, this.f90sp.y));
    }

    public void onDraw(Painting target, Canvas cvs) {
        this.draw.set((PointF) this.pivots.get(0), (PointF) this.pivots.get(1));
        this.draw.draw(target, cvs);
        target.postInvalidate();
    }

    /* access modifiers changed from: protected */
    public boolean insideFigure(PointF point) {
        return false;
    }
}
