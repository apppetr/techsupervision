package ru.sviridov.techsupervision.utils.vectors.impl.pivots;

import android.graphics.Canvas;
import android.graphics.PointF;
import android.view.MotionEvent;

import org.json.JSONException;

import java.util.ArrayList;
import ru.sviridov.techsupervision.utils.vectors.Painting;
import ru.sviridov.techsupervision.utils.vectors.impl.ArrowFImagePatch;

/* renamed from: ru.sviridov.techsupervision.utils.vectors.impl.pivots.PivotArrowInstrument */
public class PivotArrowInstrument extends PivotInstrument {
    ArrowFImagePatch draw = new ArrowFImagePatch(new PointF(), new PointF());

    /* renamed from: sp */
    PointF f89sp = new PointF();
    boolean start = true;

   public PivotArrowInstrument() throws JSONException {
   }

   /* access modifiers changed from: protected */
    public void restrictPivots(int changedPivotIndex) {
    }

    public void handleEvent(Painting target, MotionEvent event) {
        boolean z = this.start;
        this.start = false;
        if (z || false) {
            this.pivots = new ArrayList();
            this.f89sp.set(event.getX(), event.getY());
            initializePivots(target);
            this.pressedPivotIndex = 1;
        }
        super.handleEvent(target, event);
    }

    /* access modifiers changed from: protected */
    public void initializePivots(Painting target) {
        this.pivots.add(new PointF(this.f89sp.x, this.f89sp.y));
        this.pivots.add(new PointF(this.f89sp.x, this.f89sp.y));
    }

    public void onDraw(Painting target, Canvas cvs) {
        this.draw.set((PointF) this.pivots.get(1), (PointF) this.pivots.get(0));
        this.draw.draw(target, cvs);
        target.postInvalidate();
    }

    /* access modifiers changed from: protected */
    public boolean insideFigure(PointF point) {
        return false;
    }
}
