package ru.sviridov.techsupervision.utils.vectors.impl.pivots;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.support.v4.internal.view.SupportMenu;

import org.json.JSONException;

import ru.sviridov.techsupervision.utils.vectors.Painting;

/* renamed from: ru.sviridov.techsupervision.utils.vectors.impl.pivots.PivotOvalInstrument */
public class PivotOvalInstrument extends PivotInstrument {
    public PivotOvalInstrument() throws JSONException {
    }

    /* access modifiers changed from: protected */
    public void restrictPivots(int cpi) {
        int mrr = (cpi + 2) % 4;
        if (cpi % 2 == 0) {
            ((PointF) this.pivots.get(cpi)).y = ((PointF) this.pivots.get(mrr)).y;
            float f = ((((PointF) this.pivots.get(cpi)).x - ((PointF) this.pivots.get(mrr)).x) / 2.0f) + ((PointF) this.pivots.get(mrr)).x;
            ((PointF) this.pivots.get((cpi + 3) % 4)).x = f;
            ((PointF) this.pivots.get((cpi + 1) % 4)).x = f;
            return;
        }
        ((PointF) this.pivots.get(cpi)).x = ((PointF) this.pivots.get(mrr)).x;
        float f2 = ((((PointF) this.pivots.get(cpi)).y - ((PointF) this.pivots.get(mrr)).y) / 2.0f) + ((PointF) this.pivots.get(mrr)).y;
        ((PointF) this.pivots.get((cpi + 3) % 4)).y = f2;
        ((PointF) this.pivots.get((cpi + 1) % 4)).y = f2;
    }

    /* access modifiers changed from: protected */
    public void initializePivots(Painting target) {
        float size = ((float) Math.min(target.getBuffer().getHeight(), target.getBuffer().getWidth())) / 3.0f;
        float x = (float) (target.getBuffer().getWidth() / 2);
        float y = (float) (target.getBuffer().getHeight() / 2);
        PointF top = new PointF(x, y - size);
        PointF bottom = new PointF(x, y + size);
        PointF left = new PointF(x - size, y);
        PointF right = new PointF(x + size, y);
        this.pivots.add(left);
        this.pivots.add(top);
        this.pivots.add(right);
        this.pivots.add(bottom);
    }

    public void onDraw(Painting target, Canvas cvs) {
        this.paint.setColor(SupportMenu.CATEGORY_MASK);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeWidth(2.0f * target.getDensity());
        this.rax.set(((PointF) this.pivots.get(0)).x, ((PointF) this.pivots.get(1)).y, ((PointF) this.pivots.get(2)).x, ((PointF) this.pivots.get(3)).y);
        cvs.drawOval(this.rax, this.paint);
        target.postInvalidate();
    }

    public boolean insideFigure(PointF point) {
        return true;
    }
}
