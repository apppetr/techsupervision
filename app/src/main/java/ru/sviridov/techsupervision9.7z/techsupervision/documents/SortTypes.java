package ru.sviridov.techsupervision.documents;

public interface SortTypes {
   public static final int DATE = 0;
   public static final int ELEMENTS = 1;
}
