package ru.sviridov.techsupervision.utils.vectors.impl.pivots;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.MotionEvent;
import com.cab404.jsonm.core.JSONMaker;
import com.cab404.jsonm.impl.SimpleJSONMaker;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import ru.sviridov.techsupervision.utils.JSONParcelable;
import ru.sviridov.techsupervision.utils.JSONUtils;
import ru.sviridov.techsupervision.utils.vectors.ImagePatch;
import ru.sviridov.techsupervision.utils.vectors.Painter;
import ru.sviridov.techsupervision.utils.vectors.Painting;

/* renamed from: ru.sviridov.techsupervision.utils.vectors.impl.pivots.PivotInstrument */
public abstract class PivotInstrument implements Painter, Parcelable, ImagePatch, JSONParcelable {
    public static final Parcelable.Creator<PivotInstrument> CREATOR = new Parcelable.Creator<PivotInstrument>() {
        public PivotInstrument createFromParcel(Parcel in) {
            try {
                PivotInstrument instrument = (PivotInstrument) Class.forName(in.readString()).newInstance();
                int l = in.readInt();
                instrument.pivots = new ArrayList();
                for (int i = 0; i < l; i++) {
                    instrument.pivots.add(PointF.CREATOR.createFromParcel(in));
                }
                return instrument;
            } catch (InstantiationException e) {
                throw new RuntimeException("", e);
            } catch (IllegalAccessException e2) {
                throw new RuntimeException("", e2);
            } catch (ClassNotFoundException e3) {
                throw new RuntimeException("", e3);
            }
        }

        public PivotInstrument[] newArray(int size) {
            return new PivotInstrument[size];
        }
    };
    protected static final int FIGURE_DRAGGED = 65536;
    public static final JSONParcelable.Creator<PivotInstrument> JSON_CREATOR = new JSONParcelable.Creator<PivotInstrument>() {
        public PivotInstrument createFromJSONObject(JSONObject object) {
            try {
                PivotInstrument instrument = (PivotInstrument) Class.forName(object.optString("class")).newInstance();
                JSONArray pivots = object.optJSONArray("pivots");
                instrument.pivots = new ArrayList();
                for (Object point : JSONUtils.iterate(pivots)) {
                    JSONObject jobj = (JSONObject) point;
                    instrument.pivots.add(new PointF((float) jobj.optDouble("x"), (float) jobj.optDouble("y")));
                }
                instrument.onDeserialized(object.opt("dat"));
                return instrument;
            } catch (InstantiationException e) {
                throw new RuntimeException("", e);
            } catch (IllegalAccessException e2) {
                throw new RuntimeException("", e2);
            } catch (ClassNotFoundException e3) {
                throw new RuntimeException("", e3);
            }
        }
    };
    protected Paint paint = new Paint(1);
    PointF pax = new PointF();
    PointF pbx = new PointF();
    public List<PointF> pivots;
    protected int pressedPivotIndex = -1;
    RectF rax = new RectF();
    JSONMaker thing = new SimpleJSONMaker();

    /* access modifiers changed from: protected */
    public abstract void initializePivots(Painting painting);

    /* access modifiers changed from: protected */
    public abstract boolean insideFigure(PointF pointF);

    public abstract void onDraw(Painting painting, Canvas canvas);

    /* access modifiers changed from: protected */
    public abstract void restrictPivots(int i);

    public PivotInstrument() throws JSONException {
        this.thing.add("point", "{'x': *, 'y': *}");
    }

    /* access modifiers changed from: protected */
    public Object additionalObjectData() {
        return null;
    }

    /* access modifiers changed from: protected */
    public void onDeserialized(Object additionalData) {
    }

    public void handleEvent(Painting target, MotionEvent event) {
        if (this.pivots == null) {
            this.pivots = new ArrayList();
            initializePivots(target);
        }
        handleMotionEvent(target, event);
        onDraw(target, target.getBuffer());
        for (int i = 0; i < this.pivots.size(); i++) {
            drawPivot(i, target);
        }
    }

    /* access modifiers changed from: protected */
    public void handleMotionEvent(Painting target, MotionEvent event) {
        this.pax.set(event.getX(), event.getY());
        switch (event.getAction()) {
            case 0:
                float radius = pivotRadius(target);
                this.pressedPivotIndex = -1;
                int i = 0;
                while (true) {
                    if (i < this.pivots.size()) {
                        PointF p = this.pivots.get(i);
                        this.rax.set(p.x - radius, p.y - radius, p.x + radius, p.y + radius);
                        if (this.rax.contains(this.pax.x, this.pax.y)) {
                            this.pressedPivotIndex = i;
                        } else {
                            i++;
                        }
                    }
                }

            case 1:
                this.pressedPivotIndex = -1;
                return;
            case 2:
                if (this.pressedPivotIndex == 65536) {
                    moveFigure();
                    return;
                } else if (this.pressedPivotIndex != -1) {
                    this.pivots.get(this.pressedPivotIndex).set(this.pax.x, this.pax.y);
                    restrictPivots(this.pressedPivotIndex);
                    return;
                } else {
                    return;
                }
            default:
                return;
        }
    }

    /* access modifiers changed from: protected */
    public void moveFigure() {
        this.pbx.set(0.0f, 0.0f);
        for (PointF p : this.pivots) {
            this.pbx.x += p.x;
            this.pbx.y += p.y;
        }
        this.pbx.x /= (float) this.pivots.size();
        this.pbx.y /= (float) this.pivots.size();
        this.pax.x -= this.pbx.x;
        this.pax.y -= this.pbx.y;
        for (PointF p2 : this.pivots) {
            p2.x += this.pax.x;
            p2.y += this.pax.y;
        }
    }

    /* access modifiers changed from: protected */
    public float pivotRadius(Painting target) {
        return 16.0f * target.getDensity();
    }

    /* access modifiers changed from: protected */
    public void drawPivot(int position, Painting target) {
        PointF pivot = this.pivots.get(position);
        float pivotRadius = pivotRadius(target);
        this.rax.set(pivot.x - pivotRadius, pivot.y - pivotRadius, pivot.x + pivotRadius, pivot.y + pivotRadius);
        this.paint.setStyle(Paint.Style.FILL);
        this.paint.setColor(-1);
        target.getBuffer().drawOval(this.rax, this.paint);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeWidth(target.getDensity() * 4.0f);
        this.paint.setColor(-16537357);
        target.getBuffer().drawOval(this.rax, this.paint);
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(getClass().getName());
        dest.writeInt(this.pivots.size());
        for (PointF p : this.pivots) {
            p.writeToParcel(dest, 0);
        }
    }

    public int describeContents() {
        return 0;
    }

    public void draw(Painting target, Canvas cvs) {
        onDraw(target, cvs);
    }

    public void writeToJSONObject(JSONObject object) throws JSONException {
        object.put("class", getClass().getName());
        for (PointF p : this.pivots) {
            object.accumulate("pivots", this.thing.make("point", Float.valueOf(p.x), Float.valueOf(p.y)));
        }
        object.put("dat", additionalObjectData());
    }
}
