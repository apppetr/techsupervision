package ru.sviridov.techsupervision;

public final class BuildConfig {
   public static final String APPLICATION_ID = "ru.sviridov.techsupervision.free";
   public static final String BASE_URL = "http://techsupervision-live.appspot.com";
   public static final String BUILD_TYPE = "release";
   public static final boolean DEBUG = false;
   public static final String FLAVOR = "free";
   public static final int VERSION_CODE = 25;
   public static final String VERSION_NAME = "2.0.4f";
}
