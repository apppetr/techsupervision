package ru.sviridov.techsupervision.utils;

public interface SelectListener {
   void onSelected(Object var1);
}
