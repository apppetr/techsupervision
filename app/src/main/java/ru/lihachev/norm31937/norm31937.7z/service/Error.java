package ru.lihachev.norm31937.service;

public class Error {
   private int code;
   private String message;
}
