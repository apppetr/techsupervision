package ru.lihachev.norm31937.docx;

public interface ISaver {
   boolean save();
}
