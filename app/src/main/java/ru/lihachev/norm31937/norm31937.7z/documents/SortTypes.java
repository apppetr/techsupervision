package ru.lihachev.norm31937.documents;

public interface SortTypes {
   public static final int DATE = 0;
   public static final int ELEMENTS = 1;
}
