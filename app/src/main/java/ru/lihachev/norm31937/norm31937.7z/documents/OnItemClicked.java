package ru.lihachev.norm31937.documents;

import android.support.annotation.MenuRes;

public interface OnItemClicked {
   void onClicked(long var1, @MenuRes int var3);
}
