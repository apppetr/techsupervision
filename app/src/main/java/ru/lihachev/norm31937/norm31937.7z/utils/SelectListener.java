package ru.lihachev.norm31937.utils;

public interface SelectListener {
   void onSelected(Object var1);
}
