package ru.lihachev.norm31937.utils;

public final class StringTrimmer
{
  public static String valueOf(String paramString)
  {
    if (paramString != null) {
      return paramString.trim();
    }
    return null;
  }
}
